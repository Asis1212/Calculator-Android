package com.example.myfirstprogramhit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.text.BreakIterator;

public class MainActivityResult extends AppCompatActivity {
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_result);

        result = findViewById(R.id.ResultCalc);

        String str = getIntent().getStringExtra("key1");

        result.setText(str);
    }
}