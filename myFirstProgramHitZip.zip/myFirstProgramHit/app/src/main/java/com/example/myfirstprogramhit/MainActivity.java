package com.example.myfirstprogramhit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView result;
    float num1;
    char operator;
    float num2;
    boolean end = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.textViewResult);
    }

    public void buttonFunctionNumber(View view) {
        if(end) {
            result.setText("");
            end = false;
        }
        if(view instanceof Button) {
            Button b = (Button) view;
            String str = b.getText().toString();

            result.append(str);
        }
    }

    public void operatorFunction(View view) {

        if(view instanceof Button) {
            Button b = (Button) view;
            num1 = Float.parseFloat(result.getText().toString());
            operator = b.getText().charAt(0);

            result.setText("");
        }
    }

    public void toResult(View view) {
        if(view instanceof Button) {
            Button b = (Button) view;
            num2 = Float.parseFloat(result.getText().toString());
            double calc;
            if(operator == '+') {
                calc = num1 + num2;
            } else if(operator == '-') {
                calc = num1 - num2;
            } else if(operator == 'X') {
                calc = num1 * num2;
            } else {
                calc = num1 / num2;
            }

//            result.setText(String.valueOf(calc));
            end = true;

            Intent intent = new Intent(this, MainActivityResult.class);

            intent.putExtra("key1", String.valueOf(calc));

            startActivity(intent);
        }

    }
}